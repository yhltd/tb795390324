package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("Calcs")
public class Calcs {
    /**
     * id自增列
     */
    @TableId(value = "id" , type = IdType.AUTO)
    private Integer id;

    private String kong;

    private String B;

    private String C;

    private String D;

    private String E;

    private String F;

    private String G;

    private String H;

    private String I;

    private String J;

    private String K;

    private String L;

    private String M;

    private String N;

    private String O;

    private String P;

    private String Q;

    private String R;

    private String S;

    private String T;

    private String U;

    private String V;

    private String W;

    private String X;

    private String Y;

    private String Z;

    private String AA;

    private String AB;

    private String AC;

    private String AD;

    private String AE;

    private String AF;

    private String AG;

    private String AH;

    private String AI;

    private String AJ;

    private String AK;

    private String AL;

    private String AM;

    private String AN;

    private String AO;

    private String AP;

    private String AQ;

    private String AR;

    private String AS;

    private String AT;

    private String AU;

    private String AV;

    private String AW;

    private String AX;

    private String AY;

    private String AZ;

    private String BA;

    private String BB;

    private String BC;

    private String BD;

    private String BE;

    private String BF;

    private String BG;

    private String BH;

    private String BI;

    private String BJ;

    private String BK;

    private String BL;

    private String BM;

    private String BN;

    private String BO;

    private String BP;

    private String BQ;

    private String BR;

    private String BS;

    private String BT;

    private String BU;

    private String BV;

    private String BW;

    private String BX;

    private String BY;

    private String BZ;

    private String CA;

    private String CB;

    private String CC;

    private String CD;

    private String CE;

    private String CF;

    private String CG;

    private String CH;

    private String CI;

    private String CJ;

    private String CK;

    private String CL;

    private String CM;

    private String CN;

    private String CO;

    private String CP;

    private String CQ;

    private String CR;

    private String CS;

    private String CT;

    private String CU;

    private String CV;

    private String CW;

    private String CX;

    private String CY;

    private String CZ;

    private String DA;

    private String DB;

    private String DC;

    private String DD;

    private String DE;

    private String DF;

    private String DG;

    private String DH;

    private String DI;

    private String DJ;

    private String DK;



}
