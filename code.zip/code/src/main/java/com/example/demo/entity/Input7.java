package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("input7")
public class Input7 {
    /**
     * id自增列
     */
    @TableId(value = "id" , type = IdType.AUTO)
    private Integer id;

    private String A;

    private String B;

    private String C;

    private String D;

    private String E;

    private String F;

    private String G;

    private String H;

    private String I;

    private String J;

    private String K;

    private String L;

    private String M;

    private String N;

    private String O;

    private String P;

    private String Q;

    private String R;

    private String S;

    private String T;

    private String U;

    private String V;

    private String W;

    private String X;

    private String Y;

    private String Z;

    private String AA;

    private String AB;

    private String AC;

    private String AD;

    private String AE;

    private String AF;

    private String AG;

    private String AH;

    private String AI;

    private String AJ;

    private String AK;

    private String AL;

    private String AM;

    private String AN;

    private String AO;

    private String AP;

    private String AQ;

    private String AR;

    private String AS;

    private String AT;

    private String AU;

    private String AV;

    private String AW;

    private String AX;

    private String AY;

    private String AZ;

    private String BA;

    private String BB;
}
