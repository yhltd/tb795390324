package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("lean")
public class Lean {
    /**
     * id自增列
     */
    @TableId(value = "id" , type = IdType.AUTO)
    private Integer id;

    /**
     * A
     */
    private String A;

    /**
     * B
     */
    private String B;

    /**
     * C
     */
    private String C;

    /**
     * D
     */
    private String D;

    /**
     * E
     */
    private String E;

    /**
     * F
     */
    private String F;

    /**
     * G
     */
    private String G;

    /**
     * H
     */
    private String H;

    /**
     * I
     */
    private String I;

    /**
     * J
     */
    private String J;

    /**
     * K
     */
    private String K;

    /**
     * L
     */
    private String L;

    /**
     * M
     */
    private String M;

    /**
     * N
     */
    private String N;

    /**
     * O
     */
    private String O;

    /**
     * P
     */
    private String P;

    /**
     * Q
     */
    private String Q;

    /**
     * R
     */
    private String R;

    /**
     * S
     */
    private String S;

    /**
     * T
     */
    private String T;

    /**
     * U
     */
    private String U;

    /**
     * V
     */
    private String V;

    /**
     * W
     */
    private String W;

    /**
     * X
     */
    private String X;

    /**
     * Y
     */
    private String Y;

    /**
     * Z
     */
    private String Z;

    /**
     * AA
     */
    private String AA;

    /**
     * AB
     */
    private String AB;

    /**
     * AC
     */
    private String AC;

    /**
     * AD
     */
    private String AD;

    /**
     * AE
     */
    private String AE;

    /**
     * AF
     */
    private String AF;

    /**
     * AG
     */
    private String AG;

    /**
     * AH
     */
    private String AH;

    /**
     * AI
     */
    private String AI;

    /**
     * AJ
     */
    private String AJ;

    /**
     * AK
     */
    private String AK;

    /**
     * AL
     */
    private String AL;

    /**
     * AM
     */
    private String AM;

    /**
     * AN
     */
    private String AN;

    /**
     * AO
     */
    private String AO;

    /**
     * AP
     */
    private String AP;



}
